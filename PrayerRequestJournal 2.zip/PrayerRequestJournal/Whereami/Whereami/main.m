//
//  main.m
//  Whereami
//
//  Created by Reuben Wilson on 11/23/12.
//  Copyright (c) 2012 Reuben Wilson. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PRJAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PRJAppDelegate class]));
    }
}
