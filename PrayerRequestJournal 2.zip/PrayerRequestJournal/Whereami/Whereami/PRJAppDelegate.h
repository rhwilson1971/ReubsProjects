//
//  PRJAppDelegate.h
//  Whereami
//
//  Created by Reuben Wilson on 11/23/12.
//  Copyright (c) 2012 Reuben Wilson. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PRJViewController;

@interface PRJAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) PRJViewController *viewController;

@end
