//
//  PrayerRequestor.m
//  PrayerRequestJournal
//
//  Created by Reuben Wilson on 10/31/12.
//  Copyright (c) 2012 Reuben Wilson. All rights reserved.
//

#import "PrayerRequestor.h"


@implementation PrayerRequestor

@dynamic email;
@dynamic facebook;
@dynamic firstName;
@dynamic isActive;
@dynamic isAdmin;
@dynamic lastName;
@dynamic password;
@dynamic twitter;
@dynamic username;
@dynamic requests;

@end
