//
//  PrayerRequest.m
//  PrayerRequestJournal
//
//  Created by Reuben Wilson on 10/31/12.
//  Copyright (c) 2012 Reuben Wilson. All rights reserved.
//

#import "PrayerRequest.h"
#import "PrayerRequestor.h"
#import "PrayerResponse.h"


@implementation PrayerRequest

@dynamic dateAnswered;
@dynamic dateRequested;
@dynamic detail;
@dynamic title;
@dynamic requestor;
@dynamic responses;

@end
