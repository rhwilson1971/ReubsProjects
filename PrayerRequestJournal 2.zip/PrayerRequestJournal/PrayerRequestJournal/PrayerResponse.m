//
//  PrayerResponse.m
//  PrayerRequestJournal
//
//  Created by Reuben Wilson on 10/31/12.
//  Copyright (c) 2012 Reuben Wilson. All rights reserved.
//

#import "PrayerResponse.h"


@implementation PrayerResponse

@dynamic dateEntered;
@dynamic disposition;
@dynamic response;
@dynamic request;

@end
