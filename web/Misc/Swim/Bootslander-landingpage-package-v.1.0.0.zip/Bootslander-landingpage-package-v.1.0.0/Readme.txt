Thanks for purchasing bootslander landing page template.



Package details



Folders:

1. PSD : contains 2 psd source of template elements

2. Template : this is the main template folder of bootslander

3. Documentation : contains explanation about the template files, some guide ..etc



Files:

1. Readme.text

2. Credits.txt : Links and license of image/script source

